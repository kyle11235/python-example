#!/usr/bin/env python

from setuptools import setup

setup(
    name='babel',
    version='0.0.1',
    description='my example',
    author='someone',
    author_email='someone@example.com',
    url='https://github.com/kyle/python-example',
    packages=['pythonExample'],
    install_requires=['nltk'],
)